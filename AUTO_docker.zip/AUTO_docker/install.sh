#!/bin/bash
# Script to build container container and install
echo "Building Docker image"

docker build -t auto .

echo "Docker image auto built"

cp auto_d /usr/local/bin/

echo "Copied binary to /usr/local/bin"

echo "Type run_auto <file> to run AUTO"
