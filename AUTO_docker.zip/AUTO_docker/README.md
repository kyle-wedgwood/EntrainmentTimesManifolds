## Steps to install on MacOSX

1) Download and install the Docker desktop app [(https://www.docker.com/products/docker-desktop)](https://www.docker.com/products/docker-desktop). You may need to create a free account.
2) Make sure that you are in the Auto-Docker directory.
3) Run sudo ./install.sh to build the image and install the binary. You will need to enter your password. Have a
cup of tea as this may take some time.
4) Download and install XQuartz [(https://www.xquartz.org)](https://www.xquartz.org).
5) Start XQuartz and open up the preferences. In the Settings tab,
enable "Allow connections from network clients".
6) Restart your computer.
7) Navigate to a folder containing a python-auto executable and run
auto_d <file>.
8) You may find that you get a 'bus error' when you try to run it. If this happens, just run it again.

## Uninstalling
1) Navigate to the Auto-Docker directory.
2) Run sudo ./uninstall.sh. You will need to enter your password. This will remove the auto Docker image but not
Docker itself. This will need to be deleted separately if you no longer
wish to have it installed.
