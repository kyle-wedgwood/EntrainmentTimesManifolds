#!/bin/bash
# Script to remove docker container
echo "Removing auto Docker image"

docker rmi auto

rm /usr/local/bin/auto_d

echo "Removed binary from /usr/local/bin"
